require(ggplot2)
data = read.csv('./bike_sharing_hourly.csv')

# Qusetion 1
## 1
ggplot(data) + geom_histogram(aes(x=windspeed), binwidth = 0.075) 
## 2
ggplot(data) + geom_histogram(aes(x=windspeed, y=..density..), binwidth = 0.075) + geom_density(aes(x=windspeed, y=..density..))
## 4
mean = mean(data$windspeed)
variance = var(data$windspeed)
sd = sd(data$windspeed)
skewness = (mean - median(data$windspeed))/sd
## 5
boxplot(data$windspeed, horizontal = TRUE)
Q1 = quantile(data$windspeed, 0.25)
Q2 = quantile(data$windspeed, 0.5)
Q3 = quantile(data$windspeed, 0.75)
IQR = IQR(data$windspeed)
lower_inner = Q1 - (1.5 * IQR)
upper_inner = Q3 + (1.5 * IQR)
lower_outer = Q1 - (3 * IQR)
upper_outer = Q3 + (3 * IQR)
## 6
data$windspeed[data$windspeed>upper_inner]
data$windspeed[data$windspeed<lower_inner]


# Question 2
# 1 
ggplot(data, aes(temp, cnt)) + geom_point(size=1)
# 2
cor(data$temp, data$cnt)
# 3
ggplot(data, aes(temp, cnt)) + geom_point(size=1) + geom_smooth(method=lm)
# 4
ggplot(data, aes(hum, cnt)) + geom_point(size=1) + geom_smooth(method=lm)
cor(data$hum, data$cnt)
ggplot(data, aes(temp, casual)) + geom_point(size=1) + geom_smooth(method=lm)
cor(data$temp, data$casual)
# 5
ggplot(data, aes(x=temp, y=cnt)) + geom_hex(bins=15) + geom_smooth(color="yellow")
# 6
require(reshape2)
categories = data[,c("cnt", "temp", "hum", "atemp", "windspeed", "mnth")]
cormat <- round(cor(categories), 2)
get_lower_tri<-function(cormat){
  cormat[upper.tri(cormat)] <- NA
  return(cormat)
}
lower_tri = get_lower_tri(cormat)
melted_cormat <- melt(lower_tri)
ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + 
geom_tile() + 
scale_fill_gradient2(low = "dark blue", high = "red") +
geom_text(aes(Var1, Var2, label = value), size = 4)


# Question 3
# 1
ggplot(data=data, aes(x=weathersit)) + geom_bar()
# 2
data$weathersit2 <- factor(data$weathersit, levels=names(sort(table(data$weathersit), decreasing=FALSE)))
ggplot(data=data, aes(x=weathersit2)) + geom_bar() + coord_flip()
# 3
ftable(data$weathersit)


# Question 4
require(mosaic)
# 1
table(data$season, data$weathersit)
# 2
data$weathersit2 <- factor(data$weathersit, levels = c(1,2,3,4), labels=c("Clear", "Mist", "Light rain", "Heavy rain"))
data$season2 <- factor(data$season, levels = c(1,2,3,4), labels=c("Spring", "Summer", "Fall", "Winter"))
ggplot(data=data, aes(fill=factor(weathersit2), x=season2)) + geom_bar()
# 3
ggplot(data=data, aes(fill=factor(weathersit2), x=season2)) + geom_bar(position = "dodge")
# 4
ggplot(data=data) + 
geom_mosaic(aes(weight=season, x=product(season, weathersit2), fill=weathersit2), offset=0.01)


# Question 5
# 1
samples = diamonds[sample(nrow(diamonds), 200),]
# Jittering
ggplot(diamonds, aes(price, carat)) + geom_jitter(aes(colour=diamonds$color))
# Box-and-Whisker
ggplot(diamonds, aes(x = color, y = price/carat, fill = color)) + geom_boxplot()
# 4
ggplot(diamonds, aes(carat, price)) + coord_trans(y="log") + geom_smooth()

# Question 6
# 1 (Confidence Interval)
s_casual = sd(data$casual)
error = qnorm(0.98) * s_casual / sqrt(length(data$casual))
left <- mean(data$casual) - error
right <- mean(data$casual) + error
# 3
mean_casual = mean(data$casual)
Zs = (mean_casual - 200)/(sd(data$casual)/sqrt(length(data$casual)))
p_val = 2 * pnorm(Zs)
# 4
alpha = 0.05
se = sd(data$casual)/sqrt(length(data$casual))
I = c(alpha/2, 1-alpha/2)
q = qnorm(I, mean=40, sd=se)
p = pnorm(q, mean=mean_casual, sd=se)
type2_error = diff(p)
# 5
power = 1 - type2_error

# Question 7
# 1
x = lm(cnt ~ factor(season), data=data)
summary(x)
anova(x)
# 2
summer_winter = data[data$season%%2==0,]
# Summer
summer_data = summer_winter[summer_winter$season==2, 'cnt']
mean_summer = mean(summer_data)
sd_summer = sd(summer_data)
# Winter
winter_data = summer_winter[summer_winter$season==4, 'cnt']
mean_winter = mean(winter_data)
sd_winter = sd(winter_data)
# Standard Error
se = sqrt(sd_summer**2 / length(summer_data) + sd_winter**2 / length(winter_data))
# Zs and p-value
Zs = (sd_summer - sd_winter) / se
pnorm(Zs, lower.tail = FALSE)